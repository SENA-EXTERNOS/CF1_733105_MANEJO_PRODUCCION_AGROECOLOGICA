function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5gkQp1Fj6af":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

